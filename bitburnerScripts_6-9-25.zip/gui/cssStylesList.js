/** @param {NS} ns 
* @type {Document} doc
*/
const doc = eval("document");
export async function main(ns) {
  const styles = getComputedStyle(doc.body);
  const styleNames = [];
  let styleString = "";
  for(const style of styles){
    styleNames.push(style);
  }
  //ns.tprint(styleNames);
  for(const style of styleNames){
    //ns.tprint(style);
    styleString += `${style.toString()}\n`;
  }
  ns.tprint(styleString);
}