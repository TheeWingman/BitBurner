export const processListPayloads = {
	Grow: ["Batchers/remoteGrow.js", "grow.js"],
	Hack: ["Batchers/remoteHack.js", "hack.js"],
	Weak: ["Batchers/remoteWeak.js", "weak.js"],
	AIO: ["remoteAIO.js", "sameOrRemoteAIO.js"],
	WG: ["remoteWG.js"]

}