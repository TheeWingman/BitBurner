/** @param {NS} ns */
export async function main(ns) {
  const win = eval("window");
  win.open("","Servers","width = 300, height = 400, top = 300, left = 300");
}