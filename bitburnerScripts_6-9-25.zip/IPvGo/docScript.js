/**
 * Choose one of the empty points on the board at random to play
 */
function getRandomMove(board, validMoves) {
  const moveOptions = [];
  const size = board[0].length;

  // Look through all the points on the board
  for (let x = 0; x < size; x++) {
    for (let y = 0; y < size; y++) {
      // Make sure the point is a valid move
      const isValidMove = validMoves[x][y] === true;
      // Leave some spaces to make it harder to capture our pieces.
      // We don't want to run out of empty node connections!
      //const isNotReservedSpace = x % 2 === 1 || y % 2 === 1;

      if (isValidMove) {
        moveOptions.push([x, y]);
      }
    }
  }
  const randomIndex = Math.floor(Math.random() * moveOptions.length);
  return moveOptions[randomIndex] ?? [];
}

function expandNetwork(board, validMoves) {
  const moveOptions = [];
  const size = board[0].length;

  for (let x = 0; x < size; x++) {
    for (let y = 0; y < size; y++) {
      const frouterN = board[x]?.[y + 1] === 'X';
      const frouterE = board[x - 1]?.[y] === 'X';
      const frouterW = board[x + 1]?.[y] === 'X';
      const frouterS = board[x]?.[y - 1] === 'X';
      const isValidMove = validMoves[x][y] === true;

      if (isValidMove) {
        if (frouterN || frouterE || frouterW || frouterS) {
          moveOptions.push([x, y]);
        }
      }
    }
  }
  const randomIndex = Math.floor(Math.random() * moveOptions.length);
  return moveOptions[randomIndex] ?? [];
}

function captureOpp(board, validMoves, liberties) {
  const moveOptions = [];
  const size = board[0].length;

  for (let x = 0; x < size; x++) {
    for (let y = 0; y < size; y++) {
      const routerN = liberties[x]?.[y + 1] === 1 && board[x]?.[y + 1] === 'O';
      const routerE = liberties[x - 1]?.[y] === 1 && board[x - 1]?.[y] === 'O';
      const routerW = liberties[x + 1]?.[y] === 1 && board[x + 1]?.[y] === 'O';
      const routerS = liberties[x]?.[y - 1] === 1 && board[x]?.[y - 1] === 'O';
      const isValidMove = validMoves[x][y] === true;

      if (isValidMove) {
        if (routerN || routerE || routerW || routerS) {
          moveOptions.push([x, y]);
        }
      }
    }
  }
  const randomIndex = Math.floor(Math.random() * moveOptions.length);
  return moveOptions[randomIndex] ?? [];
}

function defNet(board, validMoves, liberties, chains) {
  const moveOptions = [];
  const size = board[0].length;
  const myBigChain = 0;
  let myChains = [];

  for (let x = 0; x < size; x++) {
    for (let y = 0; y < size; y++) {
      if(board[x][y] === 'X'){
        if(!myChains.includes(chains[x][y])){
          let chainID = chains[x][y];
          let chainCt = 1;
          myChains.push({chainID, chainCt})
        }
        else{
          myChains.at(myChains.indexOf(s => s.chainID === chainID)).chainCt += 1;
        }
      }
      const routerN = liberties[x]?.[y + 1] === 1 && board[x]?.[y + 1] === 'X';
      const routerE = liberties[x - 1]?.[y] === 1 && board[x - 1]?.[y] === 'X';
      const routerW = liberties[x + 1]?.[y] === 1 && board[x + 1]?.[y] === 'X';
      const routerS = liberties[x]?.[y - 1] === 1 && board[x]?.[y - 1] === 'X';
      const isValidMove = validMoves[x][y] === true;

      if (isValidMove) {
        if (routerN || routerE || routerW || routerS) {
          moveOptions.push([x, y]);
        }
      }
    }
  }
  const randomIndex = Math.floor(Math.random() * moveOptions.length);
  for(const chain of myChains){
    if(chain.chainCt > myBigChain){
      myBigChain = chain.chainID;
    }
  }
  for(const mov of moveOptions){
    
  }
  return moveOptions[randomIndex] ?? [];
}
/** @param {NS} ns */
export async function main(ns) {
  ns.ui.openTail();
  ns.disableLog('ALL');
  if (ns.scriptRunning("IPvGo/docScript.js", "home")) {
    const numRun = ns.ps("home").filter(s => s.filename === "IPvGo/docScript.js");
    if (numRun.length > 1) {
      ns.kill(numRun[0].pid);
    }
  }
  let prevSub = [ns.go.getOpponent(), ns.go.getBoardState().length];
  const opponent = ["Previous", "Netburners", "Slum Snakes", "The Black Hand", "Tetrads", "Daedalus", "Illuminati"];

  const ans1 = await ns.prompt("Choose Opp", { type: "select", choices: opponent });
  ns.print(ans1);
  if (ans1 != "Previous") {
    prevSub[0] = ans1;
    prevSub[1] = await ns.prompt("Choose Board Size", { type: "select", choices: [5, 7, 9, 13] });
  }
  while (true) {
    let stats = ns.go.analysis.getStats();
    let gameState = ns.go.getGameState();
    let result, x, y;

    ns.go.resetBoardState(prevSub[0], prevSub[1]);

    do {

      ns.clearLog();
      const board = ns.go.getBoardState();
      const validMoves = ns.go.analysis.getValidMoves();
      const libs = ns.go.analysis.getLiberties();
      const chains = ns.go.analysis.getChains();

      ns.print(`Opp: Daedalus
        Bonuses: ${stats.Daedalus.bonusDescription}
                 ${ns.formatPercent(stats.Daedalus.bonusPercent)}
        Opp: Netburners
        Bonuses: ${stats.Netburners.bonusDescription}
                 ${ns.formatPercent(stats.Netburners.bonusPercent)}
                 `);
      ns.print(`Current Opp: ${prevSub[0]}
      `);
      ns.print("Board        Liberties");
      for (let i = 0; i < board.length; i++) {
        ns.print(`${board[i]}    ${libs[i]}`);
      }

      const [randX, randY] = getRandomMove(board, validMoves);
      const [expX, expY] = expandNetwork(board, validMoves);
      const [capX, capY] = captureOpp(board, validMoves, libs);
      const [defX, defY] = defNet(board, validMoves, libs, chains);
      // TODO: more move options

      // Choose a move from our options
      if (defX != null && defY != null) {
        x = defX;
        y = defY;
      }
      else if (capX != null && capY != null) {
        x = capX;
        y = capY;
      }
      else if (expX != null && expY != null) {
        x = expX;
        y = expY;
      }
      else {
        x = randX;
        y = randY;
      }
      if (x === undefined && result != undefined) {
        // Pass turn if no moves are found
        result = await ns.go.passTurn();
      } else {
        // Play the selected move
        result = await ns.go.makeMove(x, y);
      }

      // Log opponent's next move, once it happens
      await ns.go.opponentNextTurn();

      //await ns.sleep(200);

      // Keep looping as long as the opponent is playing moves
    } while (result.type !== "gameOver");
    ns.print("Game Over");
    gameState = ns.go.getGameState();
    ns.print(`
    Opp Score: ${gameState.whiteScore}
    Plr Score: ${gameState.blackScore}`);
    if (gameState.blackScore > gameState.whiteScore) {
      ns.print("WINNER");
    }
    else { ns.print("LOSER"); }
    await ns.sleep(2000);
  }
}