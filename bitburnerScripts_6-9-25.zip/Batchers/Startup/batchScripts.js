/** @param {NS} ns */
export async function main(ns) {
  let pidBatch = ns.run("Batchers/10pct/Manager.js",1,"foodnstuff");
  while(!ns.scan().includes("pserv-24") || ns.hacknet.numNodes < 25){
    await ns.sleep(1000);
  }
  if(ns.getPurchasedServerLimit > 0){
    ns.run("upgradePserv.js",1,1024);
  }
  while(ns.getServerMaxRam("pserv-24") < 1024 || ns.hacknet.getNodeStats(24).ram < 1024){
    await ns.sleep(1000);
  }
  ns.kill(pidBatch);
  pidBatch = ns.run("Batchers/10pct/Manager.js",1,"joesguns");
}