/** @param {NS} ns */
export async function main(ns) {
  ns.tprint(`Ppl Killed: ${ns.getPlayer().numPeopleKilled}`);
}