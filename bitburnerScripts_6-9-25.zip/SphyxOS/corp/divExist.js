/** @param {NS} ns */
export async function main(ns) {
  let port = ns.getPortHandle(ns.pid)
  let result = false
  try {
    ns.corporation.getDivision(ns.args[0])
    result = true
  }
  catch {}
  ns.atExit(() => port.write(result))
}