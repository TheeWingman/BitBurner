import { gangRecruit, gangAscend, gangEquip, setWar, gangCreate, gangGetMembers, gangGetMembersFull, gangInGang } from "SphyxOS/util.js"
import { gangGetGangInfo, gangGetOtherGangInfo, gangRespectForNext, getBNMults, hasBN, getFacRep, gangSetMemberTask } from "SphyxOS/util.js"
import { joinFac, getPlay, travelCity, getWork, setGym, getMoneyAvail, doCrime } from "SphyxOS/util.js"
import { hasSleeves, sleeveShockRecovery, sleeveSync } from "SphyxOS/util.js"
import { sleeveTravel, sleeveSetToGym, sleeveSetToCrime, getSleeveObject } from "SphyxOS/util.js"
const WIDTH = 1055
const HEIGHT = 660
const STATS = 30
const GANG_NAME = "Slum Snakes"
const MAX_MEMBERS = 12
const WIN_WAR_CHANCE = .8
const WAR_CUTOFF = .9
const MIN_TERRITORY_START_WAR = .99
const COMBAT_STAT_TRAIN = 60
const WORKERS = 9 / 12
let BUYING_GEAR = false
let MODE = "Respect" //Respect, Money
let AUTO = true //Whether or not we automatically switch workers, turn on buying eq, ascend, etc.
let SLEEVES = false
let SLEEVEACCESS = false
const SLEEVESTATS = 30
const SLEEVESHOCK = 97
let HASBN4 = false
let memberNames;
let fullMembers;
let gangInfo;
let otherGangInfo;
let respectForNext;
let bitnodeMults;

/** @param {NS} ns */
export async function main(ns) {
  ns.disableLog("ALL")
  ns.ui.openTail()
  ns.ui.resizeTail(WIDTH, HEIGHT)
  ns.writePort(6, ns.pid)
  ns.atExit(() => {
    ns.clearPort(6)
    ns.writePort(1, 1)
  })

  //Are we strong enough?
  /** @type {Player} me */
  let me = await getPlay(ns)
  let skls = me.skills
  HASBN4 = await hasBN(ns, 4, 2)
  let wrk = HASBN4 ? await getWork(ns) : false
  let haveGang = await gangInGang(ns)
  SLEEVEACCESS = await hasSleeves(ns)
  
  while (!haveGang && (skls.agility < STATS || skls.defense < STATS || skls.dexterity < STATS || skls.strength < STATS)) {
    await getCommands(ns)
    me = await getPlay(ns)
    skls = me.skills
    wrk = HASBN4 ? await getWork(ns) : false
    if (SLEEVEACCESS && SLEEVES) await sleeveWork(ns)

    if (me.city !== "Sector-12") {
      ns.clearLog()
      //Travel to our Gym
      ns.clearLog()
      ns.print("Please go to Sector-12")
      if (HASBN4) await travelCity(ns, "Sector-12")
      await ns.sleep(1000)
      continue
    }
    if (skls.strength < STATS) {
      ns.clearLog()
      ns.print("Train Str to 30")
      if (SLEEVEACCESS && SLEEVES) await displaySleeves(ns)
      if (wrk === null || (wrk && wrk.classType !== "Strength")) {
        await setGym(ns, "powerhouse gym", "Str")
      }
      await ns.sleep(1000)
      continue
    }
    if (skls.defense < STATS) {
      ns.clearLog()
      ns.print("Train Def to 30")
      if (SLEEVEACCESS && SLEEVES) await displaySleeves(ns)
      if (wrk === null || (wrk && wrk.classType !== "Defence")) {
        await setGym(ns, "powerhouse gym", "Def")
      }
      await ns.sleep(1000)
      continue
    }
    if (skls.dexterity < STATS) {
      ns.clearLog()
      ns.print("Train Dex to 30")
      if (SLEEVEACCESS && SLEEVES) await displaySleeves(ns)
      if (wrk === null || (wrk && wrk.classType !== "Dexterity")) {
        await setGym(ns, "powerhouse gym", "Dex")
      }
      await ns.sleep(1000)
      continue
    }
    if (skls.agility < STATS) {
      ns.clearLog()
      ns.print("Train Agi to 30")
      if (SLEEVEACCESS && SLEEVES) await displaySleeves(ns)
      if (wrk === null || (wrk && wrk.classType !== "Agility")) {
        await setGym(ns, "powerhouse gym", "Agi")
      }
      await ns.sleep(1000)
      continue
    }
  }
  ns.print("Do Homicide")
  if (HASBN4) await doCrime(ns, "Homicide") //Automatic switch to homicide
  //Do we have enough money, and are we bad enough yet?
  let currentMoney = await getMoneyAvail(ns, "home")
  while ((currentMoney < 1000000 || ns.heart.break() > -9) && !haveGang) {
    await getCommands(ns)
    if (SLEEVEACCESS && SLEEVES) await sleeveWork(ns)
    currentMoney = await getMoneyAvail(ns, "home")
    haveGang = await gangInGang(ns)
    let wrk = HASBN4 ? await getWork(ns) : false
    ns.clearLog()
    ns.print("Do Homicide for Money and Karma")
    ns.print("Join Slum Snakes when you can")
    if (SLEEVEACCESS && SLEEVES) await displaySleeves(ns)
    if (HASBN4 && wrk && wrk.crimeType !== "Homicide") {
      await doCrime(ns, "Homicide")
    }
    await ns.sleep(1000)
    continue
  }




  let count = 0
  let prev = 0
  let buf = ""
  //Are we in a gang yet?
  await gangCreate(ns, GANG_NAME)
  while (!haveGang) {
    await getCommands(ns)
    if (HASBN4) await joinFac(ns, GANG_NAME)
    await gangCreate(ns, GANG_NAME)
    count--
    if (count < 0) {
      count = 30
      const karma = ns.heart.break()
      let result = 0
      if (prev === 0) {
        result = 0
      }
      else {
        result = ((-54000 - karma) / ((karma - prev) / 30)) * 1000
      }
      buf = ns.sprintf("Karma: %s / -54000  ETA: %s", karma.toFixed(0), result === 0 ? "n/a" : ns.tFormat(result))
      prev = karma
    }
    haveGang = await gangInGang(ns)
    ns.clearLog()
    ns.printf("%s", buf)
    if (SLEEVEACCESS && SLEEVES) {
      await sleeveWork(ns)
      await displaySleeves(ns)
    }
    await ns.sleep(1000)
  }
  ns.resizeTail(WIDTH, HEIGHT)
  bitnodeMults = await getBNMults(ns)
  MODE = ns.args.includes("money") ? "Money" : "Respect"
  while (true) {
    memberNames = await gangGetMembers(ns)
    fullMembers = await gangGetMembersFull(ns)
    gangInfo = await gangGetGangInfo(ns)
    otherGangInfo = await gangGetOtherGangInfo(ns)
    respectForNext = await gangRespectForNext(ns)
    if (SLEEVEACCESS && SLEEVES) await sleeveWork(ns)
    BUYING_GEAR = AUTO && memberNames.length === MAX_MEMBERS ? true : AUTO ? false : BUYING_GEAR
    if (memberNames.length !== MAX_MEMBERS) await gangRecruit(ns)
    if (AUTO && BUYING_GEAR) await gangEquip(ns)
    await gangAscend(ns)
    const territoryWinChance = await war(ns)
    await assignMembers(ns, territoryWinChance)

    //Get sleeve work:  if (SLEEVEACCESS && SLEEVES) sleeveWork(ns)
    await getCommands(ns)
    await updateDisplay(ns)
    await ns.sleep(100)
  }
}
/** @param {NS} ns */
async function sleeveWork(ns) {
  //We should have access to sleeves now to get here
  const sleeves = await getSleeveObject(ns)
  for (const slv of sleeves) {
    if (slv.me.shock > SLEEVESHOCK) {
      //We need to ensure we are deshocking
      await sleeveShockRecovery(ns, slv.num)
      continue
    }
    if (slv.me.sync < 100) {
      //We need to ensure we are Synced up.  Shouldn't normally be an issue
      await sleeveSync(ns, slv.num)
      continue
    }
    //Make sure we are in Sector-12
    if (slv.me.city !== "Sector-12") {
      if (!await sleeveTravel(ns, slv.num, "Sector-12")) continue
    }
    if (slv.me.skills.strength < SLEEVESTATS) {
      if (slv.task === null || slv.task.classType !== "Strength") {
        await sleeveSetToGym(ns, slv.num, "powerhouse gym", "Str")
      }
      continue
    }
    if (slv.me.skills.defense < SLEEVESTATS) {
      if (slv.task === null || slv.task.classType !== "Defence") {
        await sleeveSetToGym(ns, slv.num, "powerhouse gym", "Def")
      }
      continue
    }
    if (slv.me.skills.dexterity < SLEEVESTATS) {
      if (slv.task === null || slv.task.classType !== "Dexterity") {
        await sleeveSetToGym(ns, slv.num, "powerhouse gym", "Dex")
      }
      continue
    }
    if (slv.me.skills.agility < SLEEVESTATS) {
      if (slv.task === null || slv.task.classType !== "Agility") {
        await sleeveSetToGym(ns, slv.num, "powerhouse gym", "Agi")
      }
      continue
    }
    //Done training, do crime
    if (slv.task === null || slv.task.crimeType !== "Homicide") {
      await sleeveSetToCrime(ns, slv.num, "Homicide")
      continue
    }
  }
}

async function war(ns) {
  if (gangInfo.territory < MIN_TERRITORY_START_WAR) {
    let lowestwinchance = 1

    for (const otherGang of combatGangs.concat(hackingGangs)) {
      if (otherGang == gangInfo.faction) {
        continue
      }
      else if (otherGangInfo[otherGang].territory <= 0) {
        continue
      }
      else {
        let othergangpower = otherGangInfo[otherGang].power
        let winChance = gangInfo.power / (gangInfo.power + othergangpower)
        lowestwinchance = Math.min(lowestwinchance, winChance)
      }
    }
    if (lowestwinchance > WIN_WAR_CHANCE) {
      if (!gangInfo.territoryWarfareEngaged) {
        await setWar(ns, true)
      }
    }
    else if (gangInfo.territoryWarfareEngaged) {
      await setWar(ns, false)
    }
    return lowestwinchance
  }
  else if (gangInfo.territoryWarfareEngaged) {
    await setWar(ns, false)
  }
  return 1
}
/** @param {NS} ns */
async function assignMembers(ns, territoryWinChance) {
  const sortedNames = fullMembers.sort((a, b) => memberCombatStats(b) - memberCombatStats(a))
  let workJobs = Math.ceil((memberNames.length) * WORKERS)
  let wantedLevelIncrease = 0
  for (let member of sortedNames) {
    let highestTaskValue = 0
    let highestValueTask = "Train Combat"
    const vigilanteDecrease = fWantedGain(member, ns.gang.getTaskStats("Vigilante Justice"))
    if (workJobs > 0 && gangInfo.territory < 1 && memberNames.length >= MAX_MEMBERS && territoryWinChance < WAR_CUTOFF) {
      // support territory warfare if max team size, not at max territory yet and win chance not high enough yet
      workJobs--
      highestValueTask = "Territory Warfare"
    }
    else if (memberCombatStats(member) < COMBAT_STAT_TRAIN) {
      highestValueTask = "Train Combat"
    }
    else if (workJobs > 0 && (wantedLevelIncrease + gangInfo.wantedLevel - 1 > vigilanteDecrease * -1 * 5 || wantedLevelIncrease + gangInfo.wantedLevel > 20)) {
      workJobs--
      highestValueTask = "Vigilante Justice"
      wantedLevelIncrease += vigilanteDecrease * 5
    }
    else if (workJobs > 0) {
      workJobs--
      for (const task of tasks.map((t) => ns.gang.getTaskStats(t))) {
        if (taskValue(ns, member, task) > highestTaskValue) {
          highestTaskValue = taskValue(ns, member, task)
          highestValueTask = task
        }
      }
      wantedLevelIncrease += fWantedGain(member, highestValueTask) * 5
      highestValueTask = highestValueTask.name
    }
    if (member.task !== highestValueTask) {
      await gangSetMemberTask(ns, member.name, highestValueTask)
    }
  }
}
function memberCombatStats(member) {
  return (member.str + member.def + member.dex + member.agi) / 4
}
/** @param {NS} ns */
function taskValue(ns, member, task) {
  // determine money and reputation gain for a task
  let respect = fRespectGain(member, task)
  let cash = fMoneyGain(member, task)
  let wantedLevelIncrease = fWantedGain(member, task)
  let vigilanteWantedDecrease = fWantedGain(member, ns.gang.getTaskStats("Vigilante Justice"))

  if (wantedLevelIncrease + vigilanteWantedDecrease > 0) {
    //avoid tasks where more than one vigilante justice is needed to compensate
    return 0
  }
  //else if ((2 * wantedLevelIncrease) + vigilanteWantedDecrease > 0) {
  // Simple compensation for wanted level since we need more vigilante then
  // ToDo: Could be a more sophisticated formula here
  //cash *= 0.75;
  //}

  return MODE === "Respect" ? respect : cash
}
/** @param {NS} ns */
async function updateDisplay(ns) {
  ns.clearLog()
  ns.printf("Name: %s", gangInfo.faction)
  ns.printf("Respect: %s (%s/s)", ns.formatNumber(gangInfo.respect), ns.formatNumber(gangInfo.respectGainRate * 5))
  ns.printf("Next Recruit: %s", respectForNext === Number.POSITIVE_INFINITY ? "MAXED" : ns.formatNumber(respectForNext))
  ns.printf("Mode: %s", MODE)
  ns.printf("Wanted Level: %s (%s/s)", ns.formatNumber(gangInfo.wantedLevel, 3), ns.formatNumber(gangInfo.wantedLevelGainRate * 5, 2))
  ns.printf("Wanted Penalty: %s%s", ns.formatNumber((gangInfo.wantedPenalty - 1) * 100), "%")
  ns.printf("Money Gains: %s/s", ns.formatNumber(moneyIncrease(ns) * 5))
  //ns.printf("Reputation: %s", ns.formatNumber(ns.singularity.getFactionRep(gangInfo.faction)))
  if (HASBN4) ns.printf("Reputation: %s", ns.formatNumber(await getFacRep(ns, gangInfo.faction)))
  ns.printf("Territory: %s%s", ns.formatNumber(gangInfo.territory * 100, 2), "%")
  ns.printf("Power: %s", ns.formatNumber(gangInfo.power))
  ns.printf("Clash Win Chance: %s%s", ns.formatNumber(clashwin() * 100, 2), "%")
  ns.printf("Territory Warfare: %s", gangInfo.territoryWarfareEngaged ? "Engaged" : gangInfo.territory == 1 ? "Finished" : "Waiting")
  ns.printf("------------------------------------------------------------------------------------------------------------")
  ns.printf("%10s %20s %6s %6s %6s %6s %6s %6s %6s %8s %8s %6s %2s", "Name", "Task", "Hack", "Str", "Def", "Dex", "Agi", "Cha", "$/s", "R/s", "Wanted", "Respct", "EQ")
  for (const me of fullMembers.sort((a, b) => a.str > b.str)) {
    ns.printf("%10s %20s %6s %6s %6s %6s %6s %6s %6s %8s %8s %6s %2s", me.name, me.task.substring(0, 19), ns.formatNumber(me.hack, 1), ns.formatNumber(me.str, 1), ns.formatNumber(me.def, 1), ns.formatNumber(me.dex, 1), ns.formatNumber(me.agi, 1), ns.formatNumber(me.cha, 1), ns.formatNumber(me.moneyGain * 5, 1), ns.formatNumber(me.respectGain * 5), ns.formatNumber(me.wantedLevelGain * 5), ns.formatNumber(me.earnedRespect, 1), geteq(ns, me))
  }
}
/** @param {NS} ns */
async function displaySleeves(ns) {
  ns.print("Sleeve Statistics:")
  ns.printf("%s: %8s %8s %8s %8s %8s %8s %8s %8s %s", "#", "Hack", "Str", "Def", "Dex", "Agi", "Cha", "Shock", "Action", "Name")
  //num, me, task
  const sleeves = await getSleeveObject(ns)
  for (const slv of sleeves) {
    ns.printf("%s: %8s %8s %8s %8s %8s %8s %8s %8s %s", slv.num, ns.formatNumber(slv.me.skills.hacking, 3), ns.formatNumber(slv.me.skills.strength, 3), ns.formatNumber(slv.me.skills.defense, 3), ns.formatNumber(slv.me.skills.dexterity, 3), ns.formatNumber(slv.me.skills.agility, 3), ns.formatNumber(slv.me.skills.charisma, 3), ns.formatNumber(slv.me.shock, 2), slv.task === null ? "Shock Recovery" : slv.task.type, slv.task.actionType || slv.task.classType || slv.task.crimeType || "n/a")
  }
}

/** @param {NS} ns */
function moneyIncrease(ns) {
  let moneygain = 0
  for (const name of fullMembers) moneygain += name.moneyGain
  return moneygain
}

/** @param {NS} ns */
function geteq(ns, soldier) {
  return soldier.augmentations.length + soldier.upgrades.length
}

/** @param {NS} ns */
function clashwin() {
  let lowestwinchance = 1
  for (const otherGang of combatGangs.concat(hackingGangs)) {
    if (otherGang === gangInfo.faction) continue
    else if (otherGangInfo[otherGang].territory <= 0) continue
    else {
      let othergangpower = otherGangInfo[otherGang].power
      let winChance = gangInfo.power / (gangInfo.power + othergangpower)
      lowestwinchance = Math.min(lowestwinchance, winChance)
    }
  }
  return lowestwinchance
}
/** @param {NS} ns */
function fWantedGain(member, task) {
  if (task.baseWanted === 0) return 0
  let statWeight =
    (task.hackWeight / 100) * member.hack +
    (task.strWeight / 100) * member.str +
    (task.defWeight / 100) * member.def +
    (task.dexWeight / 100) * member.dex +
    (task.agiWeight / 100) * member.agi +
    (task.chaWeight / 100) * member.cha
  statWeight -= 3.5 * task.difficulty
  if (statWeight <= 0) return 0;
  const territoryMult = Math.max(0.005, Math.pow(gangInfo.territory * 100, task.territory.wanted) / 100);
  if (isNaN(territoryMult) || territoryMult <= 0) return 0;
  if (task.baseWanted < 0) {
    return 0.4 * task.baseWanted * statWeight * territoryMult;
  }
  const calc = (7 * task.baseWanted) / Math.pow(3 * statWeight * territoryMult, 0.8);

  // Put an arbitrary cap on this to prevent wanted level from rising too fast if the
  // denominator is very small. Might want to rethink formula later
  return Math.min(100, calc);
}
/** @param {NS} ns */
function fRespectGain(member, task) {
  if (task.baseRespect === 0) return 0;
  let statWeight =
    (task.hackWeight / 100) * member.hack +
    (task.strWeight / 100) * member.str +
    (task.defWeight / 100) * member.def +
    (task.dexWeight / 100) * member.dex +
    (task.agiWeight / 100) * member.agi +
    (task.chaWeight / 100) * member.cha;
  statWeight -= 4 * task.difficulty;
  if (statWeight <= 0) return 0;
  const territoryMult = Math.max(0.005, Math.pow(gangInfo.territory * 100, task.territory.respect) / 100);
  const territoryPenalty = bitnodeMults ? (0.2 * gangInfo.territory + 0.8) * bitnodeMults.GangSoftcap : (0.2 * gangInfo.territory + 0.8)
  if (isNaN(territoryMult) || territoryMult <= 0) return 0;
  const respectMult = calculateWantedPenalty();
  return Math.pow(11 * task.baseRespect * statWeight * territoryMult * respectMult, territoryPenalty);
}
/** @param {NS} ns */
function fMoneyGain(member, task) {
  if (task.baseMoney === 0) return 0;
  let statWeight =
    (task.hackWeight / 100) * member.hack +
    (task.strWeight / 100) * member.str +
    (task.defWeight / 100) * member.def +
    (task.dexWeight / 100) * member.dex +
    (task.agiWeight / 100) * member.agi +
    (task.chaWeight / 100) * member.cha;

  statWeight -= 3.2 * task.difficulty;
  if (statWeight <= 0) return 0;
  const territoryMult = Math.max(0.005, Math.pow(gangInfo.territory * 100, task.territory.money) / 100);
  if (isNaN(territoryMult) || territoryMult <= 0) return 0;
  const respectMult = calculateWantedPenalty();
  let territoryPenalty = bitnodeMults ? (0.2 * gangInfo.territory + 0.8) * bitnodeMults.GangSoftcap : (0.2 * gangInfo.territory + 0.8)
  return Math.pow(5 * task.baseMoney * statWeight * territoryMult * respectMult, territoryPenalty);
}

function calculateWantedPenalty() {
  return gangInfo.respect / (gangInfo.respect + gangInfo.wantedLevel);
}
async function getCommands(ns) {
  let silent = false
  while (ns.peek(16) !== "NULL PORT DATA") {
    let result = ns.readPort(16)
    switch (result) {
      case "Auto On":
        if (!silent) ns.tprintf("Gang: Auto On!")
        AUTO = true
        break
      case "Auto Off":
        if (!silent) ns.tprintf("Gang: Auto Off!")
        AUTO = false
        break
      case "Sleeves On":
        if (!silent) ns.tprintf("Gang: Sleeves On!")
        SLEEVES = true
        break
      case "Sleeves Off":
        if (!silent) ns.tprintf("Gang: Sleeves Off!")
        SLEEVES = false
        break
      case "Respect":
        if (!silent) ns.tprintf("Gang: Respect Mode!")
        MODE = "Respect"
        break
      case "Money":
        if (!silent) ns.tprintf("Gang: Money Mode!")
        MODE = "Money"
        break
      case "Buy EQ":
        if (!silent) ns.tprintf("Gang: Buy EQ for all!")
        await gangEquip(ns)
        break
      case "Ascend":
        if (!silent) ns.tprintf("Gang: Ascend Forced")
        await gangAscend(ns, true)
        break
      case "Silent":
        silent = true
        break
      default:
        ns.tprintf("Invalid command received in gang: %s", result)
        break;
    }
  }
}


/*const names = ["Rocko", "Mike", "Jack", "Rudo", "Charmichal", "Percy", "Gloria", "Jessica", "Kelly", "Sam", "Gloria", "Sarah",
  "Jackson", "Adam", "Bob", "Carl", "Dominique", "Enrique", "Falcon", "Garry", "Helen", "Ivana", "Jeremy", "Kyle", "Lucca",
  "Max", "Nordic", "Oscar", "Paul", "Q", "Rodric", "Steve", "Trevor", "Ulfric", "Volcof", "Wilson", "Xena", "Yoril", "Z"]
*/
const tasks = ["Mug People", "Deal Drugs", "Strongarm Civilians", "Run a Con", "Armed Robbery", "Traffick Illegal Arms", "Threaten & Blackmail", "Human Trafficking", "Terrorism"];
const combatGangs = ["Speakers for the Dead", "The Dark Army", "The Syndicate", "Tetrads", "Slum Snakes"]
const hackingGangs = ["NiteSec", "The Black Hand"]