import { getBestFavor, getBestRep, getPlay, getAugsFromFaction, getOwnedAugs, purchaseAug, upgHomeRam } from "SphyxOS/util.js"
import { getReputationFromDonation, getGangFaction, getFactionFav, getFacRep, donateToFac } from "SphyxOS/util.js"
/** @param {NS} ns */
export async function main(ns) {
  ns.disableLog("ALL")
  const player = await getPlay(ns)
  const factions = player.factions
  let gangFaction = await getGangFaction(ns)
  for (const faction of factions) {
    const purchased = await getOwnedAugs(ns, true)
    /**@type {String[]} purchasable */
    let purchasable = await getAugsFromFaction(ns, faction)
    purchasable = purchasable.filter((p) => !purchased.includes(p)).sort((a, b) => ns.singularity.getAugmentationPrice(b) - ns.singularity.getAugmentationPrice(a))
    const pNoNFG = purchasable.filter((s) => s !== "NeuroFlux Governor")
    for (const aug of pNoNFG) {
      //If we cant buy it and we have enough favor to donate, donate enough to get it
      if (!await purchaseAug(ns, faction, aug) && await getFactionFav(ns, faction) >= 150 && faction !== gangFaction && faction !== "Bladeburners" && faction !== "Charity") {
        if (ns.singularity.getAugmentationPrice(aug) > ns.getServerMoneyAvailable("home")) break //If we can't afford the augment, stop donating
        const donate = await getReputationFromDonation(ns, 1e6) //Rep for donating 1e6 dollars
        const rep = await getFacRep(ns, faction)
        const targetrep = ns.singularity.getAugmentationRepReq(aug)
        if (!await donateToFac(ns, faction, ((targetrep - rep) / donate * 1e6) + 1)) break
        await purchaseAug(ns, faction, aug)        
      }
    } //End of pNoNFG
  } //End of factions

  //Ram Upgrading Round
  while (await upgHomeRam(ns)) { }
  const bestRep = await getBestRep(ns)///Has faction ahd rep attributes
  //First round of neuroflux - targetted at the best reputation place we have, filtering out gang and Bladeburners
  if (bestRep.rep > 0) while (await purchaseAug(ns, bestRep.faction, "NeuroFlux Governor")) { }
  //Donation round
  const bestFavor = await getBestFavor(ns)//Has faction and favor attributes
  debugger
  if (bestFavor.favor >= 150) {
    while (true) {
      await purchaseAug(ns, bestFavor.faction, "NeuroFlux Governor") //Buy it
      const donate = await getReputationFromDonation(ns, 1e6) //Rep for donating 1e6 dollars
      const rep = await getFacRep(ns, bestFavor.faction)
      const targetRep = ns.singularity.getAugmentationRepReq("NeuroFlux Governor")
      if (ns.singularity.getAugmentationPrice("NeuroFlux Governor") > ns.getServerMoneyAvailable("home")) break
      if (rep >= targetRep) continue //We have enough rep, continue
      if (!await donateToFac(ns, bestFavor.faction, ((targetRep - rep) / donate * 1e6) + 1)) {
        await donateToFac(ns, bestFavor.faction, ns.getServerMoneyAvailable("home"))
        break
      }
    }
  }
}