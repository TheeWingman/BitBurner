import { runIt, doKill, virus, getResetInf, getOwnedSF, wastePids, getPlay } from "SphyxOS/util.js"
import { sleeveGetNum, sleeveIdle } from "SphyxOS/util.js"
/*Static port numbers for comms:
 * 1 - this script (loader) receive
 * 2 - puppetMini: emit pid
 * 3 - puppetMini: emit bestTarget
 * 4 - stocks: emit pid
 * 5 - ipvgo: emit pid
 * 6 - gangs: emit pid
 * 7 - sleeves: emit pid
 * 8 - BB: emit pid
 * 10- casino: emit pid
 * 12 - puppetMini receive
 * 13 - stocks receive
 * 15 - ipvgo receive
 * 16 - gangs receive
 * 17 - sleeves receive
 * 18 - BB receive
 * 30 - autoInfil:
 */

//Batcher Variables
let batcherUseHacknet = false
let batcherBuyServers = true
let batcherAutoHash = false
let batcherAutoBuyHacknet = false
//Stock Variables
let stocksAutoBuy = false
//IPvGo Variables
let ipvgoRepeatStatus = true
let ipvgoCheatsStatus = true
let ipvgoLoggingStatus = false
let ipvgoPlayAsWhiteStatus = false
let oppNetburners = true
let oppSlumSnakes = true
let oppBlackHand = true
let oppTetrads = true
let oppDaedalus = true
let oppIlluminati = true
let oppRedPill = true
let oppNoAI = false
//Gangs
let gangMode = "Respect" //Each mode button just sets this mode, then refreshes
let gangAuto = true //Automatically progress the gang, buy eq, ascend, etc
//Sleves
let sleeveMode = "Recovery" //Gangs, BladeBurner, Training, Money, Recovery, Sync, Karma, Int, Idle
let sleeveInstallMode = false
//Share
let shareMode = false
//AutoInfil
let autoInfilAuto = true
let autoInfilFaction = "None"
let autoInfilMoney = true
//BB
let bbSleeveInfilOnly = false
let bbFinisher = false
let bbIntMode = false

/** @param {NS} ns */
export async function main(ns) {
  ns.ui.openTail()
  ns.disableLog("ALL")
  ns.clearLog()
  ns.ui.resizeTail(680, 620)
  await init(ns)
  await virus(ns)
  /**@type {ResetInfo} resetInfo */
  const resetInfo = await getResetInf(ns)
  const sourceFiles = await getOwnedSF(ns)

  if (ns.args.includes("BBRestart")) { //Restart from BB
    if (hasBN(ns, resetInfo, sourceFiles, 10)) { //Sleeves
      sleeveMode = "BB"
      bbFinisher = true
      await startBB(ns)
      await startBatcher(ns)
    }
  }


  while (true) {
    ns.clearLog()
    //Refresh!
    const buttonRefreshStyle = `
    .buttonRefresh{background-color: ${"green"}}
    .buttonOpenLogs{background-color: ${"green"}}
    .buttonClearActive{background-color: ${"green"}};`;
    const buttonRefresh = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonRefreshStyle),
      React.createElement("div", null,
        React.createElement("button", { className: "buttonRefresh", onClick: () => startRefresh(ns) }, "Refresh"),
        React.createElement("button", { className: "buttonOpenLogs", onClick: () => startOpenLogs(ns) }, "Re-Open Logs"),
        React.createElement("button", { className: "buttonClearActive", onClick: () => startClearActive(ns) }, "Clear Active")))

    //Batcher Button
    const batcherStatusColour = ns.peek(2) !== "NULL PORT DATA" ? "green" : "red"
    const batcherStatusHacknetColor = batcherUseHacknet ? "green" : "red"
    const batcherBuyServersColor = batcherBuyServers ? "green" : "red"
    const batcherAutoHashColor = batcherAutoHash ? "green" : "red"
    const batcherStatusName = ns.peek(2) !== "NULL PORT DATA" ? "De-Activate" : "Activate"
    const buttonBatcherStyle = `
    .buttonBatcher{background-color: ${batcherStatusColour}}
    .useHacknet{background-color: ${batcherStatusHacknetColor}}
    .autoHash{background-color: ${batcherAutoHashColor}}
    .buyServers{background-color: ${batcherBuyServersColor}};`;
    const buttonUseHacknet = hasBN(ns, resetInfo, sourceFiles, 9) ? React.createElement("button", { className: "useHacknet", onClick: () => toggleHacknet(ns) }, "Use Hacknet") : ""
    const buttonAutoHash = hasBN(ns, resetInfo, sourceFiles, 9) ? React.createElement("button", { className: "autoHash", onClick: () => toggleAutoHash(ns) }, "Auto Hash") : ""

    const buttonBatcher = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonBatcherStyle),
      React.createElement("div", null, "Batcher Status  : ",
        React.createElement("button", { className: "buttonBatcher", onClick: () => startBatcher(ns) }, batcherStatusName),
        React.createElement("button", { className: "buyServers", onClick: () => togglePurchaseServers(ns) }, "Auto-Buy Servers"),
        buttonUseHacknet,
        buttonAutoHash))

    //AutoInfil Button
    const autoInfilColour = ns.peek(30) !== "NULL PORT DATA" ? "green" : "red"
    const autoInfilAutoColour = autoInfilAuto ? "green" : "red"
    const autoInfilMoneyColour = autoInfilMoney ? "green" : "red"
    const autoInfilFactionColour = autoInfilFaction === "None" ? "red" : "green"
    const autoInfilName = ns.peek(30) !== "NULL PORT DATA" ? "De-Activate" : "Activate"
    const autoInfilFactionName = autoInfilFaction === "None" ? "" : autoInfilFaction
    const buttonAutoInfilStyle = `
    .buttonAutoInfil{background-color: ${autoInfilColour}}
    .buttonAutoInfilAuto{background-color: ${autoInfilAutoColour}}
    .buttonAutoInfilMoney{background-color: ${autoInfilMoneyColour}}
    .buttonAutoInfilFaction{background-color: ${autoInfilFactionColour}};`;
    const buttonAutoInfil = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonAutoInfilStyle),
      React.createElement("div", null, "AutoInfil Status: ",
        React.createElement("button", { className: "buttonAutoInfil", onClick: () => startAutoInfil(ns) }, autoInfilName),
        React.createElement("button", { className: "buttonAutoInfilAuto", onClick: () => startAutoInfilAuto(ns) }, "Auto"),
        React.createElement("button", { className: "buttonAutoInfilMoney", onClick: () => startAutoInfilMoney(ns) }, "Money"),
        React.createElement("button", { className: "buttonAutoInfilFaction", onClick: () => startAutoInfilFaction(ns) }, "Faction"),
        React.createElement("text", undefined, autoInfilFactionName)))

    //DevMenu Button
    const buttonDevMenuStyle = `
    .button{background-color: ${"green"}};`;
    const buttonDevMenu = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonDevMenuStyle),
      React.createElement("div", null, "Start Dev Menu  : ",
        React.createElement("button", { className: "button", onClick: () => startDevMenu(ns) }, "Dev Menu"),
        React.createElement("button", { className: "button", onClick: () => startAchievements(ns) }, "Unlock All Achievements")))

    //Casino Button
    const casinoColour = ns.peek(10) !== "NULL PORT DATA" ? "green" : "red"
    const casinoName = ns.peek(10) !== "NULL PORT DATA" ? "De-Activate" : "Activate"
    const buttonCasinoStyle = `
    .buttonCasino{background-color: ${casinoColour}};`;
    const buttonCasino = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonCasinoStyle),
      React.createElement("div", null, "Casino Status   : ",
        React.createElement("button", { className: "buttonCasino", onClick: () => startCasino(ns) }, casinoName)))

    //DumpMoney Button
    const buttonDumpMoneyStyle = `
    .buttonDumpMoney{background-color: ${"green"}};`;
    const buttonDumpMoney = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonDumpMoneyStyle),
      React.createElement("div", null, "Dump Money      : ",
        React.createElement("button", { className: "buttonDumpMoney", onClick: () => startDumpMoney(ns) }, "Dump Money")))

    //Misc Button
    const buttonShareColour = shareMode ? "green" : "red"
    const buttonCCTStyle = `
    .buttonCCT{background-color: ${"green"}}
    .buttonShare{background-color: ${buttonShareColour}};`;
    const buttonCCT = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonCCTStyle),
      React.createElement("div", null, "Miscellaneous   : ",
        React.createElement("button", { className: "buttonCCT", onClick: () => startCCT(ns) }, "Solve Contracts"),
        React.createElement("button", { className: "buttonShare", onClick: () => startShare(ns) }, "Share Ram")))

    const buttonAutoBuyHacknet = hasBN(ns, resetInfo, sourceFiles, 9) ? React.createElement("button", { className: "buttonAutoBuyHashnet", onClick: () => toggleAutoBuyHacknet(ns) }, "Batcher: AutoBuy") : ""
    //Hacknet Purchaser
    const buttonHacknetStyle = `
    .buttonHacknet{background-color: ${"green"}}
    .buttonAutoBuyHashnet{background-color: ${batcherAutoBuyHacknet ? "green" : "red"}};`;
    const buttonHacknet = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonHacknetStyle),
      React.createElement("div", null, "Hacknet Purchase: ",
        React.createElement("button", { className: "buttonHacknet", onClick: () => buyHacknet(ns) }, "Purchase Hacknet"),
        buttonAutoBuyHacknet))

    //Hashnet Buttons
    const hashMinStatusColour = ns.peek(3) !== "NULL PORT DATA" ? "green" : "red"
    const hashMaxStatusColour = ns.peek(3) !== "NULL PORT DATA" ? "green" : "red"
    const hashCorpStatusColour = ns.corporation.hasCorporation() ? "green" : "red"
    const hashResearchStatusColour = ns.corporation.hasCorporation() ? "green" : "red"
    const hashBBRankStatusColour = ns.bladeburner.inBladeburner() ? "green" : "red"
    const hashBBSPStatusColour = ns.bladeburner.inBladeburner() ? "green" : "red"
    const hashFavorStatusColour = hasBN(ns, resetInfo, sourceFiles, 4) ? "green" : "red"

    const buttonHashFavor = hasBN(ns, resetInfo, sourceFiles, 4) ? React.createElement("button", { className: "hashFavor", onClick: () => hashIt(ns, "favor") }, "Boost Job Favor") : ""

    const buttonHashStyle = `
    .hashGreen{background-color: green}
    .hashMin{background-color: ${hashMinStatusColour}}
    .hashMax{background-color: ${hashMaxStatusColour}}
    .hashCorp{background-color: ${hashCorpStatusColour}}
    .hashResearch{background-color: ${hashResearchStatusColour}}
    .hashBBRank{background-color: ${hashBBRankStatusColour}}
    .hashBBSP{background-color: ${hashBBSPStatusColour}}
    .hashFavor{background-color: ${hashFavorStatusColour}};`;
    //Row 1
    const buttonHash1 = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonHashStyle),
      React.createElement("div", null, "Hashing         : ",
        React.createElement("button", { className: "hashGreen", onClick: () => hashIt(ns, "money") }, "Money"),
        React.createElement("button", { className: "hashMin", onClick: () => hashIt(ns, "min") }, "Reduce Min Sec"),
        React.createElement("button", { className: "hashMax", onClick: () => hashIt(ns, "max") }, "Increase Max Money"),
        React.createElement("button", { className: "hashGreen", onClick: () => hashIt(ns, "coding") }, "Generate Contract")))
    //Row 2
    const buttonHash2 = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonHashStyle),
      React.createElement("div", null, "                : ",
        React.createElement("button", { className: "hashCorp", onClick: () => hashIt(ns, "corp") }, "Corp Money"),
        React.createElement("button", { className: "hashResearch", onClick: () => hashIt(ns, "research") }, "Corp Research"),
        React.createElement("button", { className: "hashBBRank", onClick: () => hashIt(ns, "bbrank") }, "Increase BB Rank"),
        React.createElement("button", { className: "hashBBSP", onClick: () => hashIt(ns, "bbsp") }, "Increase BB SP")))
    //Row 3
    const buttonHash3 = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonHashStyle),
      React.createElement("div", null, "                : ",
        React.createElement("button", { className: "hashGreen", onClick: () => hashIt(ns, "study") }, "Boost Study"),
        React.createElement("button", { className: "hashGreen", onClick: () => hashIt(ns, "train") }, "Boost Train"),
        buttonHashFavor))

    //Misc Buttons
    const buttonCrawl = React.createElement("button", { className: "button", onClick: () => startCrawlBasic(ns) }, "Backdoor") //Add the advanced one after
    const buttonTeleport = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, `.button{background-color: green}`),
      React.createElement("div", null, "Misc            : ",
        buttonCrawl,
        React.createElement("button", { className: "button", onClick: () => startTeleport(ns) }, "Teleportation"),
        React.createElement("button", { className: "button", onClick: () => startScan(ns) }, "Scan Network")))


    //Stocks Buttons
    const stocksStatusColour = ns.peek(4) !== "NULL PORT DATA" ? "green" : "red"
    const stocksStatusName = ns.peek(4) !== "NULL PORT DATA" ? "De-Activate" : "Activate"
    const stocksStatusAutoBuyColor = stocksAutoBuy ? "green" : "red"
    const stocksBuySellColor = ns.peek(4) !== "NULL PORT DATA" ? "green" : "red"
    const buttonStocksStyle = `
    .buttonBuySell{background-color: ${stocksBuySellColor}}
    .buttonStatus{background-color: ${stocksStatusColour}}
    .buttonAutoBuy{background-color: ${stocksStatusAutoBuyColor}};`;

    const buttonStocks = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonStocksStyle),
      React.createElement("div", null, "Stocks Status   : ",
        React.createElement("button", { className: "buttonStatus", onClick: () => startStocks(ns) }, stocksStatusName),
        React.createElement("button", { className: "buttonBuySell", onClick: () => toggleBuyStocks(ns) }, "Buy Stocks"),
        React.createElement("button", { className: "buttonBuySell", onClick: () => toggleSellStocks(ns) }, "Sell Stocks"),
        React.createElement("button", { className: "buttonAutoBuy", onClick: () => toggleStocksAutoBuy(ns) }, "Toggle AutoBuy")))

    // IPvGO buttons
    const ipvgoStatusColor = ns.peek(5) !== "NULL PORT DATA" ? "green" : "red"
    const ipvgoStatusName = ns.peek(5) !== "NULL PORT DATA" ? "De-Activate" : "Activate"
    const ipvgoStatusRepeatColor = ipvgoRepeatStatus ? "green" : "red"
    const ipvgoStatusPlayAsWhiteColor = ipvgoPlayAsWhiteStatus ? "green" : "red"
    const ipvgoStatusCheatsColor = ipvgoCheatsStatus ? "green" : "red"
    const ipvgoStatusLoggingColor = ipvgoLoggingStatus ? "green" : "red"
    const buttonipvgoStyle = `
    .buttonIPvGoStatus{background-color: ${ipvgoStatusColor}}
    .buttonIPvPlayAsWhite{background-color: ${ipvgoStatusPlayAsWhiteColor}}
    .buttonIPvGoRepeat{background-color: ${ipvgoStatusRepeatColor}}
    .buttonIPvGoCheats{background-color: ${ipvgoStatusCheatsColor}}
    .buttonIPvGoLogging{background-color: ${ipvgoStatusLoggingColor}};`;
    const buttonIPvGo = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonipvgoStyle),
      React.createElement("div", null, "IPvGo Status    : ",
        React.createElement("button", { className: "buttonIPvGoStatus", onClick: () => startIPvGo(ns) }, ipvgoStatusName),
        React.createElement("button", { className: "buttonIPvPlayAsWhite", onClick: () => toggleIPvGoPlayAswhite(ns) }, "PlayWhite"),
        React.createElement("button", { className: "buttonIPvGoRepeat", onClick: () => toggleIPvGoRepeat(ns) }, "Repeat"),
        React.createElement("button", { className: "buttonIPvGoCheats", onClick: () => toggleIPvGoCheats(ns) }, "Cheats"),
        React.createElement("button", { className: "buttonIPvGoLogging", onClick: () => toggleIPvGoLogging(ns) }, "Logging")))

    // IPvGO Opponent buttons 1
    const ipvgoNetburnStatusColor = oppNetburners ? "green" : "red"
    const ipvgoSlumsStatusColor = oppSlumSnakes ? "green" : "red"
    const ipvgoBlackHandStatusColor = oppBlackHand ? "green" : "red"
    const ipvgoTetradsStatusColor = oppTetrads ? "green" : "red"
    const buttonipvgoOpp1Style = `
    .buttonNetStatus{background-color: ${ipvgoNetburnStatusColor}}
    .buttonSlumsStatus{background-color: ${ipvgoSlumsStatusColor}}
    .buttonBHStatus{background-color: ${ipvgoBlackHandStatusColor}}
    .buttonTetradsStatus{background-color: ${ipvgoTetradsStatusColor}}`;

    const buttonIPvGoOpponents1 = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonipvgoOpp1Style),
      React.createElement("div", null, "Opponents       : ",
        React.createElement("button", { className: "buttonNetStatus", onClick: () => toggleIPvGoNetburners(ns) }, "Netburners"),
        React.createElement("button", { className: "buttonSlumsStatus", onClick: () => toggleIPvGoSlums(ns) }, "Slum Snakes"),
        React.createElement("button", { className: "buttonBHStatus", onClick: () => toggleIPvGoBlackHand(ns) }, "The Black Hand"),
        React.createElement("button", { className: "buttonTetradsStatus", onClick: () => toggleIPvGoTetrads(ns) }, "Tetrads")))

    // IPvGO Opponent buttons 2
    const ipvgoDaedalusStatusColor = oppDaedalus ? "green" : "red"
    const ipvgoIlluminatiStatusColor = oppIlluminati ? "green" : "red"
    const ipvgoRedPillStatusColor = oppRedPill ? "green" : "red"
    const ipvgoNoAIStatusColor = oppNoAI ? "green" : "red"
    const buttonipvgoOpp2Style = `
    .buttonDaedalusStatus{background-color: ${ipvgoDaedalusStatusColor}}
    .buttonIlluminatiStatus{background-color: ${ipvgoIlluminatiStatusColor}}
    .buttonRedPillStatus{background-color: ${ipvgoRedPillStatusColor}}
    .buttonNoAIStatus{background-color: ${ipvgoNoAIStatusColor}}`;
    const buttonIPvGoOpponents2 = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonipvgoOpp2Style),
      React.createElement("div", null, "                : ",
        React.createElement("button", { className: "buttonDaedalusStatus", onClick: () => toggleIPvGoDaedalus(ns) }, "Daedalus"),
        React.createElement("button", { className: "buttonIlluminatiStatus", onClick: () => toggleIPvGoIlluminati(ns) }, "Illuminati"),
        React.createElement("button", { className: "buttonRedPillStatus", onClick: () => toggleIPvGoRedPill(ns) }, "????????"),
        React.createElement("button", { className: "buttonNoAIStatus", onClick: () => toggleIPvGoNoAI(ns) }, "No AI")))

    // Gang buttons
    const gangStatusColor = ns.peek(6) !== "NULL PORT DATA" ? "green" : "red"
    const gangStatusName = ns.peek(6) !== "NULL PORT DATA" ? "De-Activate" : "Activate"
    const gangStatusAutoColor = gangAuto ? "green" : "red"
    const gangStatusRespectColor = gangMode === "Respect" ? "green" : "red"
    const gangStatusMoneyColor = gangMode === "Money" ? "green" : "red"
    const gangStatusSleeves = sleeveMode === "Gangs" ? "green" : "red"
    const gangStatusSleeveButton = hasBN(ns, resetInfo, sourceFiles, 10) ? React.createElement("button", { className: "buttonGangSleeves", onClick: () => toggleGangSleeves(ns) }, "Sleeves") : ""
    const buttonGangStyle = `
    .buttonGangStatus{background-color: ${gangStatusColor}}
    .buttonGangAuto{background-color: ${gangStatusAutoColor}}
    .buttonGangRespect{background-color: ${gangStatusRespectColor}}
    .buttonGangMoney{background-color: ${gangStatusMoneyColor}}
    .buttonGangSleeves{background-color: ${gangStatusSleeves}}
    .buttonGangBuyEQ{background-color: ${"green"}}
    .buttonGangAscend{background-color: ${"green"}};`;
    const buttonGang = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonGangStyle),
      React.createElement("div", null, "Gang Status     : ",
        React.createElement("button", { className: "buttonGangStatus", onClick: () => startGang(ns) }, gangStatusName),
        React.createElement("button", { className: "buttonGangAuto", onClick: () => toggleGangAuto(ns) }, "Auto"),
        gangStatusSleeveButton,
        React.createElement("button", { className: "buttonGangRespect", onClick: () => toggleGangRespect(ns) }, "Respect"),
        React.createElement("button", { className: "buttonGangMoney", onClick: () => toggleGangMoney(ns) }, "Money"),
        React.createElement("button", { className: "buttonGangBuyEQ", onClick: () => toggleGangBuyEQ(ns) }, "BuyEQ All"),
        React.createElement("button", { className: "buttonGangAscend", onClick: () => toggleGangAscend(ns) }, "Ascend All")))

    //Sleeve buttons 1
    const sleeveStatusColor = ns.peek(7) !== "NULL PORT DATA" ? "green" : "red"
    const sleeveStatusName = ns.peek(7) !== "NULL PORT DATA" ? "De-Activate" : "Activate"
    const sleeveStatusRecovery = sleeveMode === "Recovery" ? "green" : "red"
    const sleeveStatusSync = sleeveMode === "Sync" ? "green" : "red"
    const sleeveStatusTraining = sleeveMode === "Training" ? "green" : "red"
    const sleeveStatusInstall = sleeveInstallMode ? "green" : "red"
    const buttonSleeveStyle1 = `
    .buttonSleeveStatus{background-color: ${sleeveStatusColor}}
    .buttonSleeveRecovery{background-color: ${sleeveStatusRecovery}}
    .buttonSleeveSync{background-color: ${sleeveStatusSync}}
    .buttonSleeveTraining{background-color: ${sleeveStatusTraining}}
    .buttonSleeveInstall{background-color: ${sleeveStatusInstall}};`;
    const buttonSleeves1 = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonSleeveStyle1),
      React.createElement("div", null, "Sleeve Status   : ",
        React.createElement("button", { className: "buttonSleeveStatus", onClick: () => startSleeves(ns) }, sleeveStatusName),
        React.createElement("button", { className: "buttonSleeveRecovery", onClick: () => toggleSleeveMode(ns, "Recovery") }, "Recovery"),
        React.createElement("button", { className: "buttonSleeveSync", onClick: () => toggleSleeveMode(ns, "Sync") }, "Sync"),
        React.createElement("button", { className: "buttonSleeveTraining", onClick: () => toggleSleeveMode(ns, "Training") }, "Train"),
        React.createElement("button", { className: "buttonSleeveInstall", onClick: () => toggleSleevesInstall(ns) }, "Install Augs")))

    //Sleeve buttons 2
    const sleeveStatusMoney = sleeveMode === "Money" ? "green" : "red"
    const sleeveStatusKarma = sleeveMode === "Karma" ? "green" : "red"
    const sleeveStatusInt = sleeveMode === "Int" ? "green" : "red"
    const sleeveStatusIdle = sleeveMode === "Idle" ? "green" : "red"
    const sleeveStatusIntButton = hasBN(ns, resetInfo, sourceFiles, 5) ? React.createElement("button", { className: "buttonSleeveInt", onClick: () => toggleSleeveMode(ns, "Int") }, "Int") : ""

    const buttonSleeveStyle2 = `
    .buttonSleeveMoney{background-color: ${sleeveStatusMoney}}
    .buttonSleeveKarma{background-color: ${sleeveStatusKarma}}
    .buttonSleeveInt{background-color: ${sleeveStatusInt}}
    .buttonSleeveIdle{background-color: ${sleeveStatusIdle}};`;
    const buttonSleeves2 = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonSleeveStyle2),
      React.createElement("div", null, "                : ",
        React.createElement("button", { className: "buttonSleeveMoney", onClick: () => toggleSleeveMode(ns, "Money") }, "Money"),
        React.createElement("button", { className: "buttonSleeveKarma", onClick: () => toggleSleeveMode(ns, "Karma") }, "Karma"),
        React.createElement("button", { className: "buttonSleeveIdle", onClick: () => toggleSleeveMode(ns, "Idle") }, "Idle"),
        sleeveStatusIntButton))

    //BB Buttons
    const bbStatusColor = ns.peek(8) !== "NULL PORT DATA" ? "green" : "red"
    const bbStatusName = ns.peek(8) !== "NULL PORT DATA" ? "De-Activate" : "Activate"
    const bbStatusSleevesInfilOnly = bbSleeveInfilOnly ? "green" : "red"
    const bbStatusSleevesEnabled = sleeveMode === "BB" ? "green" : "red"
    const bbStatusFinisher = bbFinisher ? "green" : "red"
    const bbStatusIntMode = bbIntMode ? "green" : "red"

    const buttonBBStyle = `
    .buttonBBStatus{background-color: ${bbStatusColor}}
    .buttonBBFinisher{background-color: ${bbStatusFinisher}}
    .buttonBBIntMode{background-color: ${bbStatusIntMode}}    
    .buttonBBSleevesEnabled{background-color: ${bbStatusSleevesEnabled}}
    .buttonBBSleevesInfilOnly{background-color: ${bbStatusSleevesInfilOnly}};`;

    const bbSleeveButton = hasBN(ns, resetInfo, sourceFiles, 10) ? React.createElement("button", { className: "buttonBBSleevesEnabled", onClick: () => toggleSleeveMode(ns, "BB") }, "Sleeves") : null
    const bbSleeveInfilButton = hasBN(ns, resetInfo, sourceFiles, 10) ? React.createElement("button", { className: "buttonBBSleevesInfilOnly", onClick: () => toggleBBSleevesInfilOnly(ns) }, "Infil Only") : null
    const bbFinisherButton = hasBN(ns, resetInfo, sourceFiles, 4) ? React.createElement("button", { className: "buttonBBFinisher", onClick: () => toggleBBFinisher(ns) }, "Finisher") : null

    const buttonBB = React.createElement(
      React.Fragment,
      null,
      React.createElement("style", null, buttonBBStyle),
      React.createElement("div", null, "BB Status       : ",
        React.createElement("button", { className: "buttonBBStatus", onClick: () => startBB(ns) }, bbStatusName),
        bbFinisherButton,
        React.createElement("button", { className: "buttonBBIntMode", onClick: () => toggleBBIntMode(ns) }, "Int Mode"),
        bbSleeveButton,
        bbSleeveInfilButton))



    ns.printRaw(buttonRefresh)
    ns.printf("---------------------STANDARD---------------------")
    ns.printRaw(buttonBatcher)
    ns.printRaw(buttonHacknet)
    ns.printRaw(buttonTeleport)
    if (hasBN(ns, resetInfo, sourceFiles, 9)) {
      ns.printRaw(buttonHash1)
      ns.printRaw(buttonHash2)
      ns.printRaw(buttonHash3)
    }
    ns.printRaw(buttonStocks)
    ns.printRaw(buttonCCT)
    ns.printRaw(buttonIPvGo)
    ns.printRaw(buttonIPvGoOpponents1)
    ns.printRaw(buttonIPvGoOpponents2)
    if (hasBN(ns, resetInfo, sourceFiles, 2)) { // Gangs
      ns.printf("-------------------Gangs----------------------")
      ns.printRaw(buttonGang)
    }
    if (hasBN(ns, resetInfo, sourceFiles, 10)) { //Sleeves
      ns.printf("-------------------SLEEVES---------------------")
      ns.printRaw(buttonSleeves1)
      ns.printRaw(buttonSleeves2)
    }
    if (hasBN(ns, resetInfo, sourceFiles, 7) || hasBN(ns, resetInfo, sourceFiles, 6)) { // BB
      ns.printf("---------------------BB------------------------")
      ns.printRaw(buttonBB)
    }
    if (hasBN(ns, resetInfo, sourceFiles, 4)) { // Singularity Functions
      ns.printf("-------------------SINGULARITY-------------------")
      ns.printRaw(buttonDumpMoney)
    }
    ns.printf("---------------------CHEATS----------------------")
    ns.printRaw(buttonAutoInfil)
    ns.printRaw(buttonCasino)
    ns.printRaw(buttonDevMenu)
    await ns.nextPortWrite(1)
    ns.clearPort(1)
  }
}

/** @param {NS} ns */
async function startBatcher(ns) {
  if (ns.peek(2) !== "NULL PORT DATA") {
    await doKill(ns, ns.peek(2))
  }
  else {
    const commands = []
    if (batcherUseHacknet) commands.push("usehacknet")
    if (batcherAutoHash) commands.push("autohash")
    if (!batcherBuyServers) commands.push("nopurchase")
    if (batcherAutoBuyHacknet) commands.push("autobuyhacknet")
    ns.writePort(2, await runIt(ns, "SphyxOS/bins/puppetMini.js", true, commands))
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function buyHacknet(ns) {
  await runIt(ns, "SphyxOS/bins/hacknetPurchaser.js", false, [])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleHacknet(ns) {
  if (batcherUseHacknet) {
    batcherUseHacknet = !batcherUseHacknet
    if (ns.peek(2) !== "NULL PORT DATA") ns.writePort(12, "nohacknet")
  }
  else {
    batcherUseHacknet = !batcherUseHacknet
    if (ns.peek(2) !== "NULL PORT DATA") ns.writePort(12, "hacknet")
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleAutoBuyHacknet(ns) {
  if (batcherAutoBuyHacknet) {
    batcherAutoBuyHacknet = !batcherAutoBuyHacknet
    if (ns.peek(2) !== "NULL PORT DATA") ns.writePort(12, "noautobuyhacknet")
  }
  else {
    batcherAutoBuyHacknet = !batcherAutoBuyHacknet
    if (ns.peek(2) !== "NULL PORT DATA") ns.writePort(12, "autobuyhacknet")
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleAutoHash(ns) {
  if (batcherAutoHash) {
    batcherAutoHash = !batcherAutoHash
    if (ns.peek(2) !== "NULL PORT DATA") ns.writePort(12, "noautohash")
  }
  else {
    batcherAutoHash = !batcherAutoHash
    if (ns.peek(2) !== "NULL PORT DATA") ns.writePort(12, "autohash")
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function togglePurchaseServers(ns) {
  if (batcherBuyServers) {
    batcherBuyServers = !batcherBuyServers
    if (ns.peek(2) !== "NULL PORT DATA") ns.writePort(12, "nopurchaseservers")
  }
  else {
    batcherBuyServers = !batcherBuyServers
    if (ns.peek(2) !== "NULL PORT DATA") ns.writePort(12, "purchaseservers")
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startAutoInfil(ns) {
  if (ns.peek(30) !== "NULL PORT DATA") { //Stop it
    await runIt(ns, "SphyxOS/cheats/autoInfil.js", false, [])
    ns.clearPort(30)
  }
  else { //Start it

    if (!autoInfilAuto) ns.writePort(30, await runIt(ns, "SphyxOS/cheats/autoInfil.js", false, []))
    else if (autoInfilMoney) ns.writePort(30, await runIt(ns, "SphyxOS/cheats/autoInfil.js", false, ["--auto"]))
    else ns.writePort(30, await runIt(ns, "SphyxOS/cheats/autoInfil.js", false, ["--auto", "--faction", autoInfilFaction]))
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startAutoInfilAuto(ns) {
  if (autoInfilAuto) { //Turn it off
    autoInfilAuto = false
    autoInfilFaction = "None"
    autoInfilMoney = false
    if (ns.peek(30) !== "NULL PORT DATA") await runIt(ns, "SphyxOS/cheats/autoInfil.js", false, ["--update", "--quiet"])
    while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
  }
  else { //Turn it on
    autoInfilAuto = true
    autoInfilMoney = true
    autoInfilFaction = "None"
    if (ns.peek(30) !== "NULL PORT DATA") await runIt(ns, "SphyxOS/cheats/autoInfil.js", false, ["--auto", "--update", "--quiet"])
    while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
  }
}
/** @param {NS} ns */
async function startAutoInfilMoney(ns) {
  if (autoInfilMoney) { //Already on, just abort
    return
  }
  else { //Turn it on
    autoInfilAuto = true
    autoInfilMoney = true
    autoInfilFaction = "None"
    if (ns.peek(30) !== "NULL PORT DATA") await runIt(ns, "SphyxOS/cheats/autoInfil.js", false, ["--auto", "--update", "--quiet"])
    while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
  }
}
/** @param {NS} ns */
async function startAutoInfilFaction(ns) {
  autoInfilAuto = true
  autoInfilMoney = false
  const player = await getPlay(ns)
  autoInfilFaction = await ns.prompt("Select Faction", { type: "select", choices: player.factions })
  if (ns.peek(30) !== "NULL PORT DATA") await runIt(ns, "SphyxOS/cheats/autoInfil.js", false, ["--auto", "--faction", autoInfilFaction, "--update", "--quiet"])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startCasino(ns) {
  if (ns.peek(10) !== "NULL PORT DATA") {
    await doKill(ns, ns.peek(10))
    ns.clearPort(10)
  }
  else {
    ns.writePort(10, await runIt(ns, "SphyxOS/cheats/casino.js", false, []))
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startDevMenu(ns) {
  await runIt(ns, "SphyxOS/cheats/devMenu.js", false, [])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startAchievements(ns) {
  await runIt(ns, "SphyxOS/cheats/achievements.js", false, [])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startCCT(ns) {
  await runIt(ns, "SphyxOS/bins/codingContracts.js", false, [])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startShare(ns) {
  shareMode = !shareMode
  if (shareMode) await runIt(ns, "SphyxOS/bins/startShare.js", false, [])
  else await runIt(ns, "SphyxOS/bins/startShare.js", false, ["stop"])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startRefresh(ns) {
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startOpenLogs(ns) {
  if (ns.peek(2) !== "NULL PORT DATA") ns.tail(ns.peek(2)) // Puppet
  if (ns.peek(4) !== "NULL PORT DATA") ns.tail(ns.peek(4)) // Stocks
  if (ns.peek(5) !== "NULL PORT DATA") ns.tail(ns.peek(5)) // IPvGo
  if (ns.peek(6) !== "NULL PORT DATA") ns.tail(ns.peek(6)) // Gangs
  if (ns.peek(7) !== "NULL PORT DATA") ns.tail(ns.peek(7)) // Sleeves
  if (ns.peek(8) !== "NULL PORT DATA") ns.tail(ns.peek(8)) // BB
  if (ns.peek(10) !== "NULL PORT DATA") ns.tail(ns.peek(10)) // Casino
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startClearActive(ns) {
  if (ns.peek(2) !== "NULL PORT DATA" && ns.peek(2) > 0) await doKill(ns, ns.peek(2))// Puppet
  if (ns.peek(4) !== "NULL PORT DATA" && ns.peek(4) > 0) await doKill(ns, ns.peek(4))// Stocks
  if (ns.peek(5) !== "NULL PORT DATA" && ns.peek(5) > 0) await doKill(ns, ns.peek(5))// IPvGo
  if (ns.peek(6) !== "NULL PORT DATA" && ns.peek(6) > 0) await doKill(ns, ns.peek(6))// Gangs
  if (ns.peek(7) !== "NULL PORT DATA" && ns.peek(7) > 0) await doKill(ns, ns.peek(7))// Sleeves
  if (ns.peek(8) !== "NULL PORT DATA" && ns.peek(8) > 0) await doKill(ns, ns.peek(8))// BB
  if (ns.peek(10) !== "NULL PORT DATA" && ns.peek(10) > 0) await doKill(ns, ns.peek(10))// Casino
  if (shareMode) {
    shareMode = false
    await runIt(ns, "SphyxOS/bins/startShare.js", false, ["stop"])
  }
  ns.clearPort(2)// Puppet
  ns.clearPort(4)// Stocks
  ns.clearPort(5)// IPvGo
  ns.clearPort(6)// Gangs
  ns.clearPort(7)// Sleeves
  ns.clearPort(8)// BB
  ns.clearPort(10)// Casino
  ns.clearPort(30)//AutoInfil

  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startDumpMoney(ns) {
  await runIt(ns, "SphyxOS/bins/dumpMoney.js", false, [])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function hashIt(ns, type) {
  const pid = await runIt(ns, "SphyxOS/extras/hashIt.js", false, [type])
  await ns.nextPortWrite(pid)
  ns.clearPort(pid)
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startStocks(ns) {
  if (ns.peek(4) !== "NULL PORT DATA") {
    await doKill(ns, ns.peek(4))
  }
  else {
    const commands = []
    if (stocksAutoBuy) commands.push("autobuy")
    await runIt(ns, "SphyxOS/bins/tStocks.js", true, commands)
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleStocksAutoBuy(ns) {
  if (stocksAutoBuy) {
    stocksAutoBuy = !stocksAutoBuy
    if (ns.peek(4) !== "NULL PORT DATA") ns.writePort(13, "autobuyoff")
  }
  else {
    stocksAutoBuy = !stocksAutoBuy
    if (ns.peek(4) !== "NULL PORT DATA") ns.writePort(13, "autobuy")
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleBuyStocks(ns) {
  if (ns.peek(4) !== "NULL PORT DATA") ns.writePort(13, "buy")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleSellStocks(ns) {
  if (ns.peek(4) !== "NULL PORT DATA") ns.writePort(13, "sell")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startCrawlBasic(ns) {
  await runIt(ns, "SphyxOS/extras/crawl-Basic.js", true, [])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startTeleport(ns) {
  await runIt(ns, "SphyxOS/extras/teleport.js", false, [])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startScan(ns) {
  await runIt(ns, "SphyxOS/extras/scan.js", false, [])
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function startIPvGo(ns) {
  if (ns.peek(5) !== "NULL PORT DATA") {
    await doKill(ns, ns.peek(5))
  }
  else {
    ns.writePort(15, "Silent")
    ns.writePort(15, ipvgoRepeatStatus ? "Repeat On" : "Repeat Off")
    ns.writePort(15, ipvgoPlayAsWhiteStatus ? "Play as White On" : "Play as White Off")
    ns.writePort(15, ipvgoCheatsStatus ? "Cheats On" : "Cheats Off")
    ns.writePort(15, ipvgoLoggingStatus ? "Logging On" : "Logging Off")
    ns.writePort(15, oppNetburners ? "Net On" : "Net Off")
    ns.writePort(15, oppSlumSnakes ? "Slum On" : "Slum Off")
    ns.writePort(15, oppBlackHand ? "BH On" : "BH Off")
    ns.writePort(15, oppTetrads ? "Tetrad On" : "Tetrad Off")
    ns.writePort(15, oppDaedalus ? "Daed On" : "Daed Off")
    ns.writePort(15, oppIlluminati ? "Illum On" : "Illum Off")
    ns.writePort(15, oppRedPill ? "???? On" : "???? Off")
    ns.writePort(15, oppNoAI ? "No AI On" : "No AI Off")
    ns.writePort(5, await runIt(ns, "SphyxOS/bins/go.js", true, []))
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoRepeat(ns) {
  ipvgoRepeatStatus = !ipvgoRepeatStatus
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, ipvgoRepeatStatus ? "Repeat On" : "Repeat Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoPlayAswhite(ns) {
  if (ipvgoPlayAsWhiteStatus) {
    ipvgoPlayAsWhiteStatus = !ipvgoPlayAsWhiteStatus
    if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, ipvgoPlayAsWhiteStatus ? "Play as White On" : "Play as White Off")
  }
  else {
    ipvgoPlayAsWhiteStatus = !ipvgoPlayAsWhiteStatus
    oppNoAI = true
    if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, ipvgoPlayAsWhiteStatus ? "Play as White On" : "Play as White Off")
    if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppNoAI ? "No AI On" : "No AI Off")
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoCheats(ns) {
  ipvgoCheatsStatus = !ipvgoCheatsStatus
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, ipvgoCheatsStatus ? "Cheats On" : "Cheats Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoLogging(ns) {
  ipvgoLoggingStatus = !ipvgoLoggingStatus
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, ipvgoLoggingStatus ? "Logging On" : "Logging Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoNetburners(ns) {
  oppNetburners = !oppNetburners
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppNetburners ? "Net On" : "Net Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoSlums(ns) {
  oppSlumSnakes = !oppSlumSnakes
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppSlumSnakes ? "Slum On" : "Slum Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoBlackHand(ns) {
  oppBlackHand = !oppBlackHand
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppBlackHand ? "BH On" : "BH Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoTetrads(ns) {
  oppTetrads = !oppTetrads
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppTetrads ? "Tetrad On" : "Tetrad Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoDaedalus(ns) {
  oppDaedalus = !oppDaedalus
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppDaedalus ? "Daed On" : "Daed Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoIlluminati(ns) {
  oppIlluminati = !oppIlluminati
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppIlluminati ? "Illum On" : "Illum Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoRedPill(ns) {
  oppRedPill = !oppRedPill
  if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppRedPill ? "???? On" : "???? Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleIPvGoNoAI(ns) {
  if (oppNoAI) {
    ipvgoPlayAsWhiteStatus = false
    oppNoAI = !oppNoAI
    if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, ipvgoPlayAsWhiteStatus ? "Play as White On" : "Play as White Off")
    if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppNoAI ? "No AI On" : "No AI Off")
  }
  else {
    oppNoAI = !oppNoAI
    if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, ipvgoPlayAsWhiteStatus ? "Play as White On" : "Play as White Off")
    if (ns.peek(5) !== "NULL PORT DATA") ns.writePort(15, oppNoAI ? "No AI On" : "No AI Off")
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
//BB
/** @param {NS} ns */
async function startBB(ns) {
  if (ns.peek(8) !== "NULL PORT DATA") {
    await doKill(ns, ns.peek(8))
  }
  else {
    ns.writePort(18, "quiet")
    ns.writePort(18, bbFinisher ? "finisher on" : "finisher off")
    ns.writePort(18, bbIntMode ? "int mode on" : "int mode off")
    ns.writePort(18, sleeveMode === "BB" ? "sleeves on" : "sleeves off")
    ns.writePort(18, bbSleeveInfilOnly ? "sleeve infil on" : "sleeve infil off")
    ns.writePort(8, await runIt(ns, "SphyxOS/bins/bb.js", true, []))
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleBBFinisher(ns) {
  bbFinisher = !bbFinisher
  if (ns.peek(8) !== "NULL PORT DATA") ns.writePort(18, bbFinisher ? "finisher on" : "finisher off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleBBIntMode(ns) {
  bbIntMode = !bbIntMode
  if (ns.peek(8) !== "NULL PORT DATA") ns.writePort(18, bbIntMode ? "int mode on" : "int mode off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleBBSleevesInfilOnly(ns) {
  bbSleeveInfilOnly = !bbSleeveInfilOnly
  if (ns.peek(8) !== "NULL PORT DATA") ns.writePort(18, bbSleeveInfilOnly ? "sleeve infil on" : "sleeve infil off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleSleeveMode(ns, mode) {
  switch (sleeveMode) { // Turn off the one that's on since it's changing
    case "Gangs":
      if (ns.peek(6) !== "NULL PORT DATA") ns.writePort(16, "Sleeves Off")
      break
    case "BB":
      if (ns.peek(8) !== "NULL PORT DATA") ns.writePort(18, "sleeves off")
      break
    case "Training":
    case "Idle":
    case "Recovery":
    case "Sync":
    case "Money":
    case "Karma":
    case "Int":
      if (ns.peek(7) !== "NULL PORT DATA"
        && !["Training", "Idle", "Recovery", "Sync", "Money", "Karma", "Int"].includes(mode)) await doKill(ns, ns.peek(7))
      break
    default:
      ns.tprintf("Invalid Sleeve mode: %s", sleeveMode)
  }
  if (sleeveMode === mode) { //turn it off and set to idle if it's the same one
    //Switch all sleeves to idle
    const numSleeves = await sleeveGetNum(ns)
    for (let slv = 0; slv < numSleeves; slv++)
      await sleeveIdle(ns, slv)
    sleeveMode = "Idle"
  }
  else {
    switch (mode) { // Turn on the new one
      case "Gangs":
        if (ns.peek(6) !== "NULL PORT DATA") ns.writePort(16, "Sleeves On")
        break
      case "BB":
        if (ns.peek(8) !== "NULL PORT DATA") ns.writePort(18, "sleeves on")
        break
      case "Training":
      case "Idle":
      case "Recovery":
      case "Sync":
      case "Money":
      case "Karma":
      case "Int":
        if (ns.peek(7) !== "NULL PORT DATA")
          ns.writePort(17, mode)
        break
      default:
        ns.tprintf("Invalid Sleeve mode: %s", mode)
    }
    sleeveMode = mode
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}

//Gangs
/** @param {NS} ns */
async function startGang(ns) {
  if (ns.peek(6) !== "NULL PORT DATA") {
    await doKill(ns, ns.peek(6))
  }
  else {
    ns.writePort(16, "Silent")
    ns.writePort(16, gangAuto ? "Auto On" : "Auto Off")
    ns.writePort(16, gangMode)
    ns.writePort(16, sleeveMode === "Gangs" ? "Sleeves On" : "Sleeves Off")
    ns.writePort(6, await runIt(ns, "SphyxOS/bins/gang.js", true, []))
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleGangAuto(ns) {
  gangAuto = !gangAuto
  if (ns.peek(6) !== "NULL PORT DATA") ns.writePort(16, gangAuto ? "Auto On" : "Auto Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleGangRespect(ns) {
  gangMode = "Respect"
  if (ns.peek(6) !== "NULL PORT DATA") ns.writePort(16, gangMode)
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleGangMoney(ns) {
  gangMode = "Money"
  if (ns.peek(6) !== "NULL PORT DATA") ns.writePort(16, gangMode)
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleGangBuyEQ(ns) {
  if (ns.peek(6) !== "NULL PORT DATA") ns.writePort(16, "Buy EQ")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleGangAscend(ns) {
  if (ns.peek(6) !== "NULL PORT DATA") ns.writePort(16, "Ascend")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleGangSleeves(ns) {
  if (sleeveMode === "Gangs") {
    sleeveMode = "Recovery"
  }
  else if (["Training", "Recovery", "Sync", "Money", "Karma", "Int"].includes(sleeveMode)) {
    sleeveMode = "Gangs"
    if (ns.peek(7) !== "NULL PORT DATA") await doKill(ns, ns.peek(7))
  }
  if (ns.peek(6) !== "NULL PORT DATA") ns.writePort(16, sleeveMode === "Gangs" ? "Sleeves On" : "Sleeves Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
//Sleeves
/** @param {NS} ns */
async function startSleeves(ns) {
  if (ns.peek(7) !== "NULL PORT DATA") {
    await doKill(ns, ns.peek(7))
  }
  else {
    if (sleeveMode === "Gangs" && ns.peek(6) !== "NULL PORT DATA") {
      ns.writePort(16, "Sleeves Off")
      sleeveMode = "Recovery"
    }
    ns.writePort(17, "Silent")
    ns.writePort(17, sleeveMode)
    ns.writePort(17, sleeveInstallMode ? "Install On" : "Install Off")
    await runIt(ns, "SphyxOS/bins/tSleeves.js", true, [])
  }
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}
/** @param {NS} ns */
async function toggleSleevesInstall(ns) {
  sleeveInstallMode = !sleeveInstallMode

  if (ns.peek(7) !== "NULL PORT DATA") ns.writePort(17, sleeveInstallMode ? "Install On" : "Install Off")
  while (!ns.tryWritePort(1, 1)) await ns.sleep(4)
}



async function init(ns) {
  //We need to reserve at least 50 pids
  for (let i = 0; i < 50; i++) await wastePids(ns)
}
/**@param {NS} ns @param {ResetInfo} resetInfo @param {SourceFile} sourceFiles */
function hasBN(ns, resetInfo, sourceFiles, bn, lvl = 1) {
  if (resetInfo.currentNode === bn) return true
  try {
    for (const sf of sourceFiles) if (sf.n === bn && sf.lvl >= lvl) return true
    return false
  }
  catch { return false }
}