/** @param {NS} ns */
export async function main(ns) {
  const s = ns.singularity
  const factions = ns.getPlayer().factions
  let bestFac = "none"
  let bestRep = -1
  let gangFac = "none"

  try { gangFac = ns.gang.getGangInformation().faction } catch { }
  //Best favor for purchasing Neuroflux.  Filter out factions without it
  for (const faction of factions) {
    if (s.getFactionRep(faction) > bestRep && faction !== gangFac && faction != "Bladeburners" && faction != "Charity") {
      bestFac = faction
      bestRep = s.getFactionRep(faction)
    }
  }
  let result = {
    "faction": bestFac,
    "rep": bestRep
  }
  const port = ns.getPortHandle(ns.pid)
  ns.atExit(() => port.write(result))
}