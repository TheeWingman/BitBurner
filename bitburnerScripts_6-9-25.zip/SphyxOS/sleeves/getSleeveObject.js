/** @param {NS} ns */
export async function main(ns) {
  
  const sleeves = []
  for (let slv = 0; slv < ns.sleeve.getNumSleeves(); slv++) {
    const record = {
      "num": slv,
      "me": ns.sleeve.getSleeve(slv),
      "task": ns.sleeve.getTask(slv)
    }
    sleeves.push(record)
  }
  let port = ns.getPortHandle(ns.pid)
  ns.atExit(() => port.write(sleeves))
}