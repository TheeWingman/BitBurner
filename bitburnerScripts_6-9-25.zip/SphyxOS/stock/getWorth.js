/** @param {NS} ns */
export async function main(ns) {
  let port = ns.getPortHandle(ns.pid)
  let worth = ns.getServerMoneyAvailable("home")
  ns.atExit(() => port.write(worth))
  for (let sym of ns.stock.getSymbols()) {
    const posi = ns.stock.getPosition(sym)
    if (posi[0] > 0) {
      worth += ns.stock.getSaleGain(sym, posi[0], "long")
    }
    if (posi[2] > 0) {
      worth += ns.stock.getSaleGain(sym, posi[2], "short")
    }
  }
}