/** @param {NS} ns */
export async function main(ns) {
  let port = ns.getPortHandle(ns.pid)
  ns.atExit(() => port.write(ns.stock.hasTIXAPIAccess() ? 1 : 0))
}